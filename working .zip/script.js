/**
 * Prayer Times Dashboard - TV Display
 * Production Ready Version
 */

class PrayerTimesDashboard {
    constructor() {
        this.currentDate = new Date();
        this.currentYear = this.currentDate.getFullYear();
        this.currentMonth = this.currentDate.getMonth() + 1;
        this.prayerData = {};
        this.todayData = null;
        this.tomorrowData = null;
        this.currentPrayerIndex = -1;
        this.nextPrayerIndex = -1;

        // Slideshow variables
        this.slideshowImages = [];
        this.currentImageIndex = 0;
        this.isSlideshowActive = false;
        this.slideshowHideTimeout = null;
        this.slideshowCycleInterval = null;

        // Call for prayer variables
        this.callOverlayActive = false;
        this.callTimer = null;
        this.callCountdown = 0;
        this.currentCallPrayer = null;

        // Footer hide variables
        this.footerHidden = false;
        this.footerHideTimeout = null;

        // DOM Elements
        this.elements = {
            loadingScreen: document.getElementById('loading-screen'),
            container: document.querySelector('.container'),
            currentTime: document.getElementById('current-time'),
            currentSeconds: document.getElementById('current-seconds'),
            dayName: document.getElementById('day-name'),
            fullDate: document.getElementById('full-date'),
            hijriDate: document.getElementById('hijri-date'),
            lastUpdate: document.getElementById('last-update'),
            currentMonth: document.getElementById('current-month'),
            prayerRows: document.getElementById('prayer-rows'),
            nextPrayerName: document.getElementById('next-prayer-name'),
            nextPrayerTime: document.getElementById('next-prayer-time'),
            nextPrayerCountdown: document.getElementById('next-prayer-countdown'),
            nextPrayerHighlight: document.getElementById('next-prayer-highlight'),
            slideshowPopup: document.getElementById('slideshow-popup'),
            slideshowImage: document.getElementById('slideshow-image'),
            slideshowCaption: document.getElementById('slideshow-caption'),
            imageCounter: document.getElementById('image-counter'),
            slideshowTimerBar: document.getElementById('slideshow-timer-bar'),
            slideshowStatus: document.getElementById('slideshow-status'),
            dataStatus: document.getElementById('data-status'),
            callOverlay: document.getElementById('call-overlay'),
            callPrayerName: document.getElementById('call-prayer-name'),
            callCountdown: document.getElementById('call-countdown'),
            prevMonthBtn: document.getElementById('prev-month-btn'),
            nextMonthBtn: document.getElementById('next-month-btn'),
            footerToggleBtn: document.getElementById('footer-toggle-btn'),
            footer: document.getElementById('footer')
        };

        this.prayerOrder = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
        this.prayerIcons = {
            'Fajr': 'fas fa-sun',
            'Dhuhr': 'fas fa-sun',
            'Asr': 'fas fa-cloud-sun',
            'Maghrib': 'fas fa-sunset',
            'Isha': 'fas fa-moon'
        };
        this.prayerNames = {
            'Fajr': 'FAJR',
            'Dhuhr': 'DHUHR',
            'Asr': 'ASR',
            'Maghrib': 'MAGHRIB',
            'Isha': 'ISHA'
        };

        // Initialize dashboard
        this.init();
    }

    async init() {
        console.log('🚀 Initializing Prayer Times Dashboard...');

        try {
            // Hide loading screen after 1 second minimum
            setTimeout(() => {
                this.hideLoadingScreen();
            }, 1000);

            await Promise.all([
                this.loadPrayerData(),
                this.loadSlideshowImages()
            ]);

            this.updateDateTime();
            this.updateDisplay();
            this.setupEventListeners();
            this.setupTimers();
            this.startSlideshowCycle();
            this.setupFooterAutoHide();
            this.enterTVMode();

            console.log('✅ Dashboard ready');

        } catch (error) {
            console.error('❌ Initialization error:', error);
            this.showError('Failed to initialize dashboard. Using fallback mode.');
            this.hideLoadingScreen();
        }
    }

    hideLoadingScreen() {
        if (this.elements.loadingScreen) {
            this.elements.loadingScreen.style.opacity = '0';
            this.elements.loadingScreen.style.transition = 'opacity 0.5s ease';
            setTimeout(() => {
                this.elements.loadingScreen.style.display = 'none';
                if (this.elements.container) {
                    this.elements.container.style.display = 'flex';
                }
            }, 500);
        }
    }

    showError(message) {
        console.error('Dashboard Error:', message);
        // Update status indicators
        this.elements.dataStatus.classList.remove('warning', 'active');
        this.elements.dataStatus.classList.add('inactive');
        this.elements.dataStatus.querySelector('span').textContent = 'Data: Error';
    }

    enterTVMode() {
        // Add TV mode class
        document.body.classList.add('tv-mode');

        // Prevent context menu
        document.addEventListener('contextmenu', e => {
            e.preventDefault();
            return false;
        });

        // Prevent F11 default behavior
        document.addEventListener('keydown', (e) => {
            if (e.key === 'F11') {
                e.preventDefault();
                this.requestFullscreen();
            }
        });

        // Attempt fullscreen
        this.requestFullscreen();
    }

    requestFullscreen() {
        const elem = document.documentElement;

        if (!document.fullscreenElement) {
            if (elem.requestFullscreen) {
                elem.requestFullscreen().catch(e => {
                    console.log('Fullscreen not allowed:', e);
                    this.fallbackFullscreen();
                });
            } else if (elem.mozRequestFullScreen) {
                elem.mozRequestFullScreen();
            } else if (elem.webkitRequestFullscreen) {
                elem.webkitRequestFullscreen();
            } else if (elem.msRequestFullscreen) {
                elem.msRequestFullscreen();
            } else {
                this.fallbackFullscreen();
            }
        }
    }

    fallbackFullscreen() {
        // Apply TV mode styles
        document.body.style.position = 'fixed';
        document.body.style.top = '0';
        document.body.style.left = '0';
        document.body.style.width = '100vw';
        document.body.style.height = '100vh';
        document.body.style.margin = '0';
        document.body.style.padding = '15px';
        document.body.style.overflow = 'hidden';
        document.body.style.zIndex = '9999';

        document.documentElement.style.overflow = 'hidden';
        window.dispatchEvent(new Event('resize'));
    }

    async loadSlideshowImages() {
        try {
            // Try to load from API first
            const response = await fetch('/api/images');
            if (response.ok) {
                const data = await response.json();
                this.slideshowImages = data.images || data;
                this.updateSlideshowStatus(`Slideshow: ${this.slideshowImages.length} images`, 'active');
                return;
            }
        } catch (error) {
            console.log('API images not available, trying embedded images...');
        }

        // Try embedded images
        if (window.EMBEDDED_IMAGES && window.EMBEDDED_IMAGES.length > 0) {
            this.slideshowImages = window.EMBEDDED_IMAGES;
            this.updateSlideshowStatus(`Slideshow: ${this.slideshowImages.length} embedded images`, 'active');
            return;
        }

        // Try to load from images list file
        try {
            const response = await fetch('images_list.json');
            if (response.ok) {
                const data = await response.json();
                this.slideshowImages = data.images || data;
                this.updateSlideshowStatus(`Slideshow: ${this.slideshowImages.length} images from file`, 'active');
                return;
            }
        } catch (error) {
            console.log('Images list file not found');
        }

        // Use default images
        this.slideshowImages = [
            { src: 'images/mosque1.jpg', caption: 'Baitul Mukarram Jame Mosque' },
            { src: 'images/mosque2.jpg', caption: 'Prayer Hall Interior' },
            { src: 'images/quran.jpg', caption: 'Holy Quran' },
            { src: 'images/islamic_art.jpg', caption: 'Islamic Art & Architecture' },
            { src: 'images/prayer_mat.jpg', caption: 'Prayer Time' }
        ];

        this.updateSlideshowStatus('Slideshow: Default images', 'warning');
    }

    updateSlideshowStatus(text, status) {
        const statusEl = this.elements.slideshowStatus;
        statusEl.classList.remove('active', 'warning', 'inactive');
        statusEl.classList.add(status);
        statusEl.querySelector('span').textContent = text;
    }

    async loadPrayerData() {
        const month = String(this.currentMonth).padStart(2, '0');
        const fileName = `jamaah_times_${this.currentYear}_${month}.json`;
        const dataKey = `${this.currentYear}_${month}`;

        try {
            // Try embedded data first
            if (window.EMBEDDED_PRAYER_DATA && window.EMBEDDED_PRAYER_DATA[dataKey]) {
                this.prayerData = window.EMBEDDED_PRAYER_DATA[dataKey].prayer_times ||
                                 window.EMBEDDED_PRAYER_DATA[dataKey];
                this.updateTodayAndTomorrowData();
                this.updateDataStatus('Data: Embedded', 'active');
                return;
            }

            // Try to fetch from server
            try {
                const response = await fetch(`data/${fileName}?t=${Date.now()}`);
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                const data = await response.json();
                this.prayerData = data.prayer_times || data;
                this.updateTodayAndTomorrowData();
                this.updateDataStatus('Data: Live', 'active');
                return;
            } catch (fetchError) {
                console.log('Server fetch failed, trying fallback...');
            }

            // Use fallback data
            throw new Error('No data source available');

        } catch (error) {
            console.log('Using fallback data');
            this.loadFallbackData();
            this.updateDataStatus('Data: Fallback', 'warning');
        }
    }

    updateDataStatus(text, status) {
        const statusEl = this.elements.dataStatus;
        statusEl.classList.remove('active', 'warning', 'inactive');
        statusEl.classList.add(status);
        statusEl.querySelector('span').textContent = text;
    }

    loadFallbackData() {
        const today = this.formatDate(new Date());
        const tomorrow = this.formatDate(new Date(Date.now() + 86400000));
        const now = new Date();

        // Base times (adjust these for your location)
        const baseTimes = {
            'Fajr': '06:15',
            'Sunrise': '08:35',
            'Dhuhr': '12:20',
            'Asr': '13:45',
            'Maghrib': '15:45',
            'Isha': '17:30'
        };

        this.prayerData = {
            [today]: {
                date: today,
                day_number: now.getDate(),
                day_name: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][now.getDay()],
                is_friday: now.getDay() === 5,
                has_custom_times: false,
                beginning_times: baseTimes,
                jamaah_times: {
                    Fajr_Jamaah: '06:45',
                    Dhuhr_Jamaah: '13:00',
                    Asr_Jamaah: '14:15',
                    Maghrib_Jamaah: '15:50',
                    Isha_Jamaah: '18:00'
                }
            },
            [tomorrow]: {
                date: tomorrow,
                day_number: new Date(Date.now() + 86400000).getDate(),
                day_name: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][(now.getDay() + 1) % 7],
                is_friday: (now.getDay() + 1) % 7 === 5,
                has_custom_times: false,
                beginning_times: {
                    'Fajr': '06:20',
                    'Sunrise': '08:40',
                    'Dhuhr': '12:20',
                    'Asr': '13:45',
                    'Maghrib': '15:50',
                    'Isha': '17:35'
                },
                jamaah_times: {
                    Fajr_Jamaah: '06:50',
                    Dhuhr_Jamaah: '13:00',
                    Asr_Jamaah: '14:15',
                    Maghrib_Jamaah: '15:55',
                    Isha_Jamaah: '18:05'
                }
            }
        };

        this.updateTodayAndTomorrowData();
    }

    updateTodayAndTomorrowData() {
        const todayKey = this.formatDate(new Date());
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowKey = this.formatDate(tomorrow);

        this.todayData = this.prayerData[todayKey];
        this.tomorrowData = this.prayerData[tomorrowKey];

        // If today's data not found, find the closest available date
        if (!this.todayData) {
            const dates = Object.keys(this.prayerData);
            if (dates.length > 0) {
                const sortedDates = dates.sort();
                for (const date of sortedDates) {
                    if (date >= todayKey) {
                        this.todayData = this.prayerData[date];
                        break;
                    }
                }
                if (!this.todayData) {
                    this.todayData = this.prayerData[sortedDates[sortedDates.length - 1]];
                }
            }
        }

        // If tomorrow's data not found, find the next available date
        if (!this.tomorrowData) {
            const dates = Object.keys(this.prayerData).sort();
            const todayIndex = dates.indexOf(todayKey);
            if (todayIndex !== -1 && todayIndex + 1 < dates.length) {
                this.tomorrowData = this.prayerData[dates[todayIndex + 1]];
            } else if (dates.length > 0) {
                this.tomorrowData = this.prayerData[dates[0]];
            }
        }
    }

    updateDateTime() {
        const now = new Date();

        // Update time
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');

        this.elements.currentTime.textContent = `${hours}:${minutes}`;
        this.elements.currentSeconds.textContent = `:${seconds}`;

        // Update date
        const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                          'July', 'August', 'September', 'October', 'November', 'December'];

        this.elements.dayName.textContent = dayNames[now.getDay()];
        this.elements.fullDate.textContent = `${now.getDate()} ${monthNames[now.getMonth()]} ${now.getFullYear()}`;

        // Update Hijri date
        this.updateHijriDate(now);

        // Update month display
        this.elements.currentMonth.textContent = `${monthNames[this.currentMonth - 1].toUpperCase()} ${this.currentYear}`;

        // Update last update time
        this.elements.lastUpdate.textContent = now.toLocaleTimeString('en-US', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }

    updateHijriDate(gregorianDate) {
        // Simplified Hijri date calculation
        // In production, you should use a proper Hijri calendar library
        const hijriYear = 1446;
        const hijriMonths = ['Muharram', 'Safar', 'Rabi\' al-Awwal', 'Rabi\' al-Thani',
                            'Jumada al-Awwal', 'Jumada al-Thani', 'Rajab', 'Sha\'ban',
                            'Ramadan', 'Shawwal', 'Dhu al-Qi\'dah', 'Dhu al-Hijjah'];

        const monthIndex = gregorianDate.getMonth();
        const day = gregorianDate.getDate();

        const hijriDay = Math.max(1, (day % 30) + 1);
        const hijriMonthIndex = monthIndex % 12;

        this.elements.hijriDate.innerHTML =
            `<i class="fas fa-star-and-crescent"></i>
             <span>${hijriDay} ${hijriMonths[hijriMonthIndex]} ${hijriYear} AH</span>`;
    }

    updateDisplay() {
        if (!this.todayData || !this.tomorrowData) {
            this.showLoadingState();
            return;
        }

        this.updatePrayerStatus();
        this.renderPrayerTimes();
        this.updateNextPrayer();
        this.checkCallForPrayer();
    }

    showLoadingState() {
        this.elements.prayerRows.innerHTML = `
            <div class="loading">
                <i class="fas fa-spinner fa-spin"></i>
                Loading prayer times...
            </div>
        `;
    }

    updatePrayerStatus() {
        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();
        let currentPrayer = -1;

        this.prayerOrder.forEach((prayer, index) => {
            const jamaahTime = this.getPrayerTime(prayer, 'jamaah_times');
            if (jamaahTime && jamaahTime !== '--:--') {
                const [hours, minutes] = jamaahTime.split(':').map(Number);
                const prayerMinutes = hours * 60 + minutes;
                if (currentTime >= prayerMinutes) {
                    currentPrayer = index;
                }
            }
        });

        this.currentPrayerIndex = currentPrayer;
        this.nextPrayerIndex = currentPrayer + 1;

        if (this.nextPrayerIndex >= this.prayerOrder.length) {
            this.nextPrayerIndex = 0;
        }
    }

    getPrayerTime(prayerName, timeType = 'beginning_times') {
        const now = new Date();
        const currentTime = now.getHours() * 60 + now.getMinutes();
        let dataToUse = this.todayData;

        if (timeType === 'jamaah_times') {
            const jamaahKey = prayerName === 'Maghrib' ? 'Maghrib_Jamaah' : `${prayerName}_Jamaah`;
            const jamaahTime = this.todayData?.jamaah_times?.[jamaahKey];

            if (jamaahTime && jamaahTime !== '--:--') {
                const [hours, minutes] = jamaahTime.split(':').map(Number);
                const prayerMinutes = hours * 60 + minutes;

                if (currentTime >= prayerMinutes) {
                    dataToUse = this.tomorrowData;
                }
            }
        } else if (timeType === 'beginning_times') {
            const beginningTime = this.todayData?.beginning_times?.[prayerName];
            if (beginningTime && beginningTime !== '--:--') {
                const [hours, minutes] = beginningTime.split(':').map(Number);
                const prayerMinutes = hours * 60 + minutes;

                if (currentTime >= prayerMinutes) {
                    dataToUse = this.tomorrowData;
                }
            }
        }

        if (timeType === 'beginning_times') {
            return dataToUse?.beginning_times?.[prayerName] || '--:--';
        } else if (timeType === 'jamaah_times') {
            const jamaahKey = prayerName === 'Maghrib' ? 'Maghrib_Jamaah' : `${prayerName}_Jamaah`;
            return dataToUse?.jamaah_times?.[jamaahKey] || '--:--';
        }

        return '--:--';
    }

    calculateAdhanTime(prayerName, jamaahTime, beginningTime) {
        if (!jamaahTime || jamaahTime === '--:--') {
            return '--:--';
        }

        if (prayerName === 'Maghrib') {
            return beginningTime || jamaahTime;
        }

        try {
            return this.subtractMinutes(jamaahTime, 15);
        } catch (error) {
            return jamaahTime;
        }
    }

    subtractMinutes(timeStr, minutes) {
        const [hours, mins] = timeStr.split(':').map(Number);
        const date = new Date();
        date.setHours(hours, mins, 0, 0);
        date.setMinutes(date.getMinutes() - minutes);

        const newHours = String(date.getHours()).padStart(2, '0');
        const newMinutes = String(date.getMinutes()).padStart(2, '0');
        return `${newHours}:${newMinutes}`;
    }

    renderPrayerTimes() {
        if (!this.elements.prayerRows) return;

        let html = '';
        this.prayerOrder.forEach((prayer, index) => {
            const beginningTime = this.getPrayerTime(prayer, 'beginning_times');
            const jamaahTime = this.getPrayerTime(prayer, 'jamaah_times');
            const adhanTime = this.calculateAdhanTime(prayer, jamaahTime, beginningTime);

            let statusClass = 'status-upcoming';
            let statusText = 'UPCOMING';
            let statusIcon = 'fas fa-clock';

            if (index === this.currentPrayerIndex) {
                statusClass = 'status-current';
                statusText = 'IN PROGRESS';
                statusIcon = 'fas fa-pray';
            } else if (index < this.currentPrayerIndex) {
                statusClass = 'status-passed';
                statusText = 'COMPLETED';
                statusIcon = 'fas fa-check';
            }

            const isNextPrayer = index === this.nextPrayerIndex;
            const rowClass = isNextPrayer ? 'prayer-row next-prayer' :
                           index === this.currentPrayerIndex ? 'prayer-row current-prayer' :
                           'prayer-row';

            const callForPrayerInfo = this.getCallForPrayerInfo(prayer, adhanTime);

            html += `
                <div class="${rowClass}" data-prayer="${prayer}">
                    <div class="prayer-cell prayer-name">
                        <div class="prayer-icon">
                            <i class="${this.prayerIcons[prayer]}"></i>
                        </div>
                        ${this.prayerNames[prayer]}
                    </div>
                    <div class="prayer-cell prayer-beginning">${beginningTime}</div>
                    <div class="prayer-cell prayer-adhan">${adhanTime}</div>
                    <div class="prayer-cell prayer-jamaah">${jamaahTime}</div>
                    <div class="prayer-cell prayer-call ${callForPrayerInfo.active ? 'call-active' : ''}">
                        ${callForPrayerInfo.text}
                        ${callForPrayerInfo.active && callForPrayerInfo.countdown ?
                            `<div class="call-countdown">${callForPrayerInfo.countdown}</div>` : ''}
                    </div>
                    <div class="prayer-cell prayer-status ${statusClass}">
                        <i class="${statusIcon}"></i>
                        ${statusText}
                    </div>
                </div>
            `;
        });

        this.elements.prayerRows.innerHTML = html;
    }

    getCallForPrayerInfo(prayerName, adhanTime) {
        if (!adhanTime || adhanTime === '--:--') {
            return { active: false, text: '', countdown: '' };
        }

        const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
        if (!timeRegex.test(adhanTime)) {
            return { active: false, text: '', countdown: '' };
        }

        const now = new Date();
        const [callHours, callMinutes] = adhanTime.split(':').map(Number);
        let callDate = new Date(now);
        callDate.setHours(callHours, callMinutes, 0, 0);

        if (callDate < now) {
            callDate.setDate(callDate.getDate() + 1);
        }

        const diffMs = callDate - now;
        const diffSeconds = Math.floor(diffMs / 1000);

        if (diffSeconds >= 0 && diffSeconds <= 30) {
            return {
                active: true,
                text: `<i class="fas fa-volume-up call-icon"></i>`,
                countdown: `00:${String(30 - diffSeconds).padStart(2, '0')}`
            };
        }

        return { active: false, text: '', countdown: '' };
    }

    checkCallForPrayer() {
        if (this.callOverlayActive) return;

        const now = new Date();

        this.prayerOrder.forEach(prayer => {
            try {
                const jamaahTime = this.getPrayerTime(prayer, 'jamaah_times');
                const beginningTime = this.getPrayerTime(prayer, 'beginning_times');

                if (jamaahTime === '--:--') return;

                const adhanTime = this.calculateAdhanTime(prayer, jamaahTime, beginningTime);

                if (adhanTime === '--:--') return;

                const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
                if (!timeRegex.test(adhanTime)) return;

                const [callHours, callMinutes] = adhanTime.split(':').map(Number);
                let callDate = new Date(now);
                callDate.setHours(callHours, callMinutes, 0, 0);

                if (callDate < now) {
                    callDate.setDate(callDate.getDate() + 1);
                }

                const diffMs = callDate - now;
                const diffSeconds = Math.floor(diffMs / 1000);

                if (diffSeconds <= 60 && diffSeconds > 0) {
                    this.startCallForPrayer(prayer, diffSeconds);
                }
            } catch (error) {
                console.log('Error checking call for prayer:', error);
            }
        });
    }

    startCallForPrayer(prayerName, initialSeconds) {
        if (this.callOverlayActive && this.currentCallPrayer === prayerName) return;

        this.callOverlayActive = true;
        this.currentCallPrayer = prayerName;
        this.callCountdown = initialSeconds;

        this.elements.callPrayerName.textContent = `${this.prayerNames[prayerName]} PRAYER`;
        this.elements.callCountdown.textContent = `00:${String(this.callCountdown).padStart(2, '0')}`;
        this.elements.callOverlay.style.display = 'block';

        if (this.callTimer) {
            clearInterval(this.callTimer);
        }

        this.callTimer = setInterval(() => {
            this.callCountdown--;
            this.elements.callCountdown.textContent = `00:${String(this.callCountdown).padStart(2, '0')}`;

            if (this.callCountdown <= 0) {
                clearInterval(this.callTimer);
                this.endCallForPrayer();
            }
        }, 1000);
    }

    endCallForPrayer() {
        setTimeout(() => {
            this.callOverlayActive = false;
            this.currentCallPrayer = null;
            this.elements.callOverlay.style.display = 'none';

            if (this.callTimer) {
                clearInterval(this.callTimer);
                this.callTimer = null;
            }
        }, 1000);
    }

    updateNextPrayer() {
        if (this.nextPrayerIndex >= 0 && this.nextPrayerIndex < this.prayerOrder.length) {
            const nextPrayerName = this.prayerOrder[this.nextPrayerIndex];
            const jamaahTime = this.getPrayerTime(nextPrayerName, 'jamaah_times');

            this.elements.nextPrayerName.textContent = this.prayerNames[nextPrayerName];
            this.elements.nextPrayerTime.textContent = jamaahTime;

            const countdownText = this.getPrayerCountdownToTime(jamaahTime);
            this.elements.nextPrayerCountdown.textContent = countdownText;

            this.elements.nextPrayerHighlight.style.display = 'flex';
        } else {
            this.elements.nextPrayerHighlight.style.display = 'none';
        }
    }

    getPrayerCountdownToTime(targetTime) {
        if (targetTime === '--:--') return '--';

        const now = new Date();
        const [hours, minutes] = targetTime.split(':').map(Number);
        let targetDate = new Date(now);
        targetDate.setHours(hours, minutes, 0, 0);

        if (targetDate < now) {
            targetDate.setDate(targetDate.getDate() + 1);
        }

        const diffMs = targetDate - now;
        if (diffMs > 0 && diffMs <= 86400000) {
            const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
            const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
            const diffSeconds = Math.floor((diffMs % 60000) / 1000);

            if (diffHours > 0) {
                return `in ${diffHours}h ${diffMinutes}m`;
            } else if (diffMinutes > 0) {
                return `in ${diffMinutes}m ${diffSeconds}s`;
            } else {
                return `in ${diffSeconds}s`;
            }
        }
        return '--';
    }

    startSlideshowCycle() {
        if (this.slideshowImages.length === 0) {
            this.updateSlideshowStatus('Slideshow: No images', 'warning');
            return;
        }

        if (this.slideshowCycleInterval) {
            clearInterval(this.slideshowCycleInterval);
        }

        // Show slideshow every 2 minutes
        this.slideshowCycleInterval = setInterval(() => {
            if (this.isSlideshowActive) {
                this.hideSlideshow();
            } else {
                this.showSlideshow();
            }
        }, 120000);

        // Show first image after 15 seconds
        setTimeout(() => {
            this.showSlideshow();
        }, 15000);
    }

    showSlideshow() {
        if (this.slideshowImages.length === 0 || this.isSlideshowActive) return;

        this.isSlideshowActive = true;
        this.currentImageIndex = (this.currentImageIndex + 1) % this.slideshowImages.length;
        const image = this.slideshowImages[this.currentImageIndex];

        const img = new Image();
        img.onload = () => {
            this.elements.slideshowImage.src = image.src;
            this.elements.slideshowImage.alt = image.caption;
            this.elements.slideshowCaption.textContent = image.caption;
            this.elements.imageCounter.textContent = `${this.currentImageIndex + 1}/${this.slideshowImages.length}`;

            this.elements.slideshowPopup.style.display = 'flex';

            // Reset and start timer bar animation
            this.elements.slideshowTimerBar.style.transition = 'none';
            this.elements.slideshowTimerBar.style.width = '100%';

            // Force reflow
            void this.elements.slideshowTimerBar.offsetWidth;

            this.elements.slideshowTimerBar.style.transition = 'width 30s linear';
            this.elements.slideshowTimerBar.style.width = '0%';

            // Auto-hide after 30 seconds
            if (this.slideshowHideTimeout) {
                clearTimeout(this.slideshowHideTimeout);
            }
            this.slideshowHideTimeout = setTimeout(() => {
                this.hideSlideshow();
            }, 30000);
        };

        img.onerror = () => {
            console.log('Failed to load image:', image.src);
            this.hideSlideshow();
            setTimeout(() => {
                this.showSlideshow();
            }, 2000);
        };

        img.src = image.src;
    }

    hideSlideshow() {
        if (!this.isSlideshowActive) return;

        this.isSlideshowActive = false;
        this.elements.slideshowPopup.style.display = 'none';

        if (this.slideshowHideTimeout) {
            clearTimeout(this.slideshowHideTimeout);
            this.slideshowHideTimeout = null;
        }

        this.elements.slideshowTimerBar.style.transition = 'none';
        this.elements.slideshowTimerBar.style.width = '100%';
    }

    setupFooterAutoHide() {
        this.footerHideTimeout = setTimeout(() => {
            this.toggleFooter(false);
        }, 10000);

        document.addEventListener('mousemove', () => {
            if (this.footerHidden) {
                this.toggleFooter(true);
                clearTimeout(this.footerHideTimeout);
                this.footerHideTimeout = setTimeout(() => {
                    this.toggleFooter(false);
                }, 5000);
            }
        });
    }

    toggleFooter(show = null) {
        if (show === null) {
            this.footerHidden = !this.footerHidden;
        } else {
            this.footerHidden = !show;
        }

        if (this.footerHidden) {
            this.elements.footer.classList.add('hidden');
            this.elements.footerToggleBtn.innerHTML = '<i class="fas fa-eye"></i> Show Footer';
        } else {
            this.elements.footer.classList.remove('hidden');
            this.elements.footerToggleBtn.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Footer';
        }

        localStorage.setItem('footerHidden', this.footerHidden);
    }

    setupEventListeners() {
        // Month navigation
        this.elements.prevMonthBtn?.addEventListener('click', () => this.changeMonth(-1));
        this.elements.nextMonthBtn?.addEventListener('click', () => this.changeMonth(1));

        // Close slideshow on click
        this.elements.slideshowPopup?.addEventListener('click', (e) => {
            if (e.target === this.elements.slideshowPopup ||
                e.target.classList.contains('popup-overlay')) {
                this.hideSlideshow();
            }
        });

        // Close call overlay on click
        this.elements.callOverlay?.addEventListener('click', (e) => {
            if (e.target === this.elements.callOverlay) {
                this.endCallForPrayer();
            }
        });

        // Footer toggle button
        this.elements.footerToggleBtn?.addEventListener('click', () => {
            this.toggleFooter();
        });

        // Load saved footer state
        const savedFooterState = localStorage.getItem('footerHidden');
        if (savedFooterState === 'true') {
            this.toggleFooter(false);
        }

        // Fullscreen change listener
        document.addEventListener('fullscreenchange', () => {
            if (!document.fullscreenElement) {
                setTimeout(() => this.requestFullscreen(), 1000);
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            // Don't trigger shortcuts if user is typing
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

            switch(e.key.toLowerCase()) {
                case 's':
                    this.toggleSlideshow();
                    break;
                case 'c':
                    this.testCallForPrayer();
                    break;
                case 'escape':
                    this.hideSlideshow();
                    this.endCallForPrayer();
                    break;
                case 'r':
                    if (e.ctrlKey || e.metaKey) {
                        location.reload();
                    }
                    break;
                case 'f':
                    this.requestFullscreen();
                    break;
                case 'h':
                    this.toggleFooter();
                    break;
            }
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            this.updateDisplay();
        });

        // Handle page visibility
        document.addEventListener('visibilitychange', () => {
            if (!document.hidden) {
                this.loadPrayerData();
                this.updateDateTime();
            }
        });
    }

    toggleSlideshow() {
        if (this.isSlideshowActive) {
            this.hideSlideshow();
        } else {
            this.showSlideshow();
        }
    }

    testCallForPrayer() {
        this.startCallForPrayer('Fajr', 20);
    }

    async changeMonth(delta) {
        this.currentMonth += delta;

        if (this.currentMonth > 12) {
            this.currentMonth = 1;
            this.currentYear++;
        } else if (this.currentMonth < 1) {
            this.currentMonth = 12;
            this.currentYear--;
        }

        this.currentDate = new Date(this.currentYear, this.currentMonth - 1, 1);

        await this.loadPrayerData();
        this.updateDisplay();
        this.updateDateTime();
    }

    setupTimers() {
        // Update time every second
        setInterval(() => {
            this.updateDateTime();
        }, 1000);

        // Update display every 30 seconds
        setInterval(() => {
            this.updateDisplay();
        }, 30000);

        // Check call for prayer every second
        setInterval(() => {
            this.checkCallForPrayer();
        }, 1000);

        // Reload data every 5 minutes
        setInterval(async () => {
            await this.loadPrayerData();
            this.updateDisplay();
        }, 300000);

        // Refresh images every 30 minutes
        setInterval(async () => {
            await this.loadSlideshowImages();
        }, 30 * 60 * 1000);

        // Auto-refresh entire page every 24 hours (prevents memory leaks)
        setInterval(() => {
            location.reload();
        }, 24 * 60 * 60 * 1000);
    }

    formatDate(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }

    // Add this method to PrayerTimesDashboard class
async verifyDataLoading() {
    console.group('🔍 DATA VERIFICATION');

    // Check via API
    try {
        const response = await fetch('/api/data-status');
        const status = await response.json();
        console.log('📊 Server data status:', status);

        if (status.files.length > 0) {
            console.log('✅ Data files found on server:');
            status.files.forEach(file => {
                console.log(`   📄 ${file.name} (${(file.size/1024).toFixed(1)} KB)`);
            });
        } else {
            console.log('❌ No data files found on server');
        }
    } catch (error) {
        console.log('❌ Cannot connect to server API:', error.message);
    }

    // Try to load current month data directly
    const month = String(this.currentMonth).padStart(2, '0');
    const fileName = `jamaah_times_${this.currentYear}_${month}.json`;
    const directUrl = `data/${fileName}`;

    console.log(`🔗 Direct file URL: ${directUrl}`);

    try {
        const response = await fetch(directUrl);
        console.log(`📡 Response: ${response.status} ${response.statusText}`);

        if (response.ok) {
            const text = await response.text();
            console.log('✅ File loaded successfully');
            console.log('📝 First 200 chars:', text.substring(0, 200));

            try {
                const data = JSON.parse(text);
                console.log('✅ JSON parsed successfully');
                console.log('📦 Data keys:', Object.keys(data));

                if (data.prayer_times) {
                    const dates = Object.keys(data.prayer_times);
                    console.log(`📅 Contains ${dates.length} prayer days`);
                    console.log('📅 Dates:', dates.slice(0, 3), dates.length > 3 ? '...' : '');
                }
            } catch (e) {
                console.log('❌ JSON parse error:', e.message);
            }
        }
    } catch (error) {
        console.log('❌ Direct file fetch failed:', error.message);
    }

    console.groupEnd();
}

}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    try {
        window.dashboard = new PrayerTimesDashboard();
    } catch (error) {
        console.error('Failed to initialize dashboard:', error);
        document.body.innerHTML = `
            <div style="
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                background: linear-gradient(135deg, #0c2461 0%, #1e3799 100%);
                color: white;
                font-family: 'Poppins', sans-serif;
                text-align: center;
                padding: 20px;
            ">
                <div>
                    <h1 style="font-size: 3rem; margin-bottom: 20px;">
                        <i class="fas fa-exclamation-triangle"></i> Dashboard Error
                    </h1>
                    <p style="font-size: 1.5rem; margin-bottom: 30px;">
                        Failed to initialize the dashboard. Please check the console for details.
                    </p>
                    <button onclick="location.reload()" style="
                        background: #74c0fc;
                        color: white;
                        border: none;
                        padding: 15px 30px;
                        font-size: 1.2rem;
                        border-radius: 10px;
                        cursor: pointer;
                        margin-top: 20px;
                    ">
                        <i class="fas fa-redo"></i> Reload Dashboard
                    </button>
                </div>
            </div>
        `;
    }
});
